#!/Bin/Bash

cat $1_Dealer_schedule | grep $2 | grep "AM\|PM" | awk '{print $1, $2, $5, $6}'

